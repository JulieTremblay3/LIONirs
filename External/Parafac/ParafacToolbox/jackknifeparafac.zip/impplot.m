function [] = impplot(X,Factorsini,Factorsjk)

% RIP (Identity Match Plot) plots of the jack-knife PARAFAC results:
% predicted score for the mth sample in the mth jack-knife segment
% vs score of the mth sample in the overall model
%
% impplot(X,Factorsini,Factorsjk)
%
% Input
%
% X:            input array, which can be from three- to N-way
% Factorsini:   cell array containing the loadings of the overall PARAFAC model
% Factorsjk:    cell array containing the optimally scaled jack-knife segments
%               of the PARAFAC loadings. See JKPARAFAC.M
%
% see also parafac, jkparafac, ripplot

DimX=size(X);
[res,dim]=size(size(X));
[res,numfac,res]=size(Factorsjk{2});

% predicted concentrations

for i=1:DimX(1);
    
    disp(' ')    
    disp (['          segment number ' num2str(i)])
    disp(' ')
    
% PARAFAC predictions fixing all the modes but the first one
    
    OldLoad{1}=zeros(1,numfac);
    for j=2:dim;
        OldLoad{j}=squeeze(Factorsjk{j}(:,:,i));
    end;
    
    factorsara=parafac((reshape(X(i,:),[1 DimX(2:end)])),numfac,[],0,OldLoad,[0 ones(1,dim-1)]);
    xpredit(i,1:numfac)=factorsara{1};
end;

rows=1;
columns=1;
while rows*columns<numfac
    columns=columns+1;
    if rows*columns<numfac
    rows=rows+1;
    end;
end;

for k=1:numfac
    subplot(rows,columns,k),plot (xpredit(:,k)',Factorsini{1}(:,k)','bo')
    hold on
    intercept=[min(xpredit(:,k)) max(xpredit(:,k))];
    slope=[min(xpredit(:,k)) max(xpredit(:,k))];
    plot (intercept,slope,'r-')
    title (['component number ' num2str(k)])
    xlabel('overall model');
    ylabel('predicted sample');
    
    vvvv=axis;
    xpet=vvvv(1);
    xgran=vvvv(2);
    ypet=vvvv(3);
    ygran=vvvv(4);
    
    for i=1:DimX(1);
        text (xpredit(i,k)'+(xgran-xpet)*0.02, Factorsini{1}(i,k)'+(ygran-ypet)*0.02, num2str(i))
    end;
    axis tight
end;
