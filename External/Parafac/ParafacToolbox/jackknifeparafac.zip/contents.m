%JACK-KNIFING OF PARAFAC MODELS
% Requires N-way toolbox ver. 2 
% Jack-knifing is done using leave-one-sample-out segmentation
% and assumes that samples are in the first mode of the array.
%
% jkparafac.m  : application of the jack-knife technique to the 
%                PARAFAC model of the N-way array X. The outputs 
%                are the N-loadings of the PARAFAC model using 
%                all the samples (Factorsini, cell array) and the 
%                N-loadings of the several jack-knife segments 
%                (Factorsjk, cell array).
%
% ripplot.m    : RIP (Resample Influence Plot) plot:sum of squared  
%                residuals of the mth sample to the model calculated 
%                in the mth jack-knife iteration versus the sum of  
%                squares of the difference between the loadings. 
%                It uses Factorsini and Factorsjk obtained from 
%                jkparafac.m
%
% impplot.m    : IMP (Identity Match Plot) plot: scores obtained  
%                with the overall model versus scores predicted 
%                for the mth sample using the PARAFAC model obtained 
%                in the mth iteration. It uses Factorsini and 
%                Factorsjk obtained from jkparafac.m
