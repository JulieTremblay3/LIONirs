function [] = ripplot(X,Factorsini,Factorsjk)

% RIP (Resample Influence Plot) plots of the jack-knife PARAFAC results:
% residual of each sample (predicted in the mth jack-knife segment)
% vs difference among loadings of the different modes
%
% ripplot(X,Factorsini,Factorsjk)
%
% Input
%
% X:            input array, which can be from three- to N-way
% Factorsini:   cell array containing the loadings of the overall PARAFAC model
% Factorsjk:    cell array containing the optimally scaled jack-knife segments
%               of the PARAFAC loadings. See JKPARAFAC.M
%
% see also parafac, jkparafac, impplot

DimX=size(X);
[res,dim]=size(size(X));
[res,numfac,res]=size(Factorsjk{1});

for j=1:DimX(1);
    
    disp(' ')    
    disp (['          segment number ' num2str(j)])
    disp(' ')

    dades=squeeze(reshape(X(j,:),[1 DimX(2:end)]));

% residuals from each predicted sample to the model

    OldLoad{1}=zeros(1,numfac);
    for i=2:dim;
        factorsara{i}=squeeze(Factorsjk{i}(:,:,j));
        OldLoad{i}=factorsara{i};
    end;

    factorsara=parafac((reshape(X(j,:),[1 DimX(2:end)])),numfac,[],0,OldLoad,[0 ones(1,dim-1)]);
    
    model=factorsara{2};
    for i=3:dim;
        model=kr(factorsara{i},model);
    end;
    model=squeeze(reshape(factorsara{1}*model',[1 DimX(2:end)]));
    
    resta=model-dades;
    
    kk=isnan(resta);
    [contnan,res]=size(find(kk));
    resta(kk)=0;
    model(kk)=0;
    
    resta=resta.^2;
    residual(j)=sum(resta(:));
    residualbis(j)=residual(j)/(prod(DimX(2:end))-contnan);
    
% similarity between the loadings in the overall model and the jack-knife segments
    
    for k=1:dim-1;
        cont(k)=0;
        for m=1:DimX(k+1);
            for n=1:numfac;
                cont(k)=cont(k)+sum((Factorsini{k+1}(:,n)-Factorsjk{k+1}(:,(j-1)*numfac+n)).^2);
            end;
        end;
        difload(j,k)=cont(k);
    end;
end;

%plots

for k=1:dim-1;
    figure,plot (residualbis, difload(:,k),'bo')

    vvvv=axis;
    xpet=vvvv(1);
    xgran=vvvv(2);
    ypet=vvvv(3);
    ygran=vvvv(4);

    for i=1:DimX(1);
        text (residualbis(i)+(xgran-xpet)*0.02, difload(i,k)+(ygran-ypet)*0.02, num2str(i))
    end;

    xlabel('sum of squared residuals')
    ylabel(['difference between loadings'])
    title(['RIP plot mode ' num2str(k+1)])
end;
